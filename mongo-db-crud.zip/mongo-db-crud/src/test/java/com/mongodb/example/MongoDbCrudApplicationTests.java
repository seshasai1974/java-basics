package com.mongodb.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
