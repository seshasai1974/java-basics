package com.mongodb.example;

import org.springframework.data.mongodb.repository.MongoRepository;
  
public interface BookRepo
    extends MongoRepository<Book, Integer> {
}